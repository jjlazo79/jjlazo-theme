<p><?php echo apply_filters('jjlazo_no_posts_text', esc_html__('Sorry, no posts matched your criteria.', 'jjlazo')); ?></p>
