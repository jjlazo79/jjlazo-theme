<?php

function jjlazo_add_meta_box()
{
    add_meta_box(
        'jjlazo_post_metabox',
        __('Post Settings', 'jjlazo'),
        'jjlazo_post_metabox_html',
        'post',
        'normal',
        'default'
    );

    add_meta_box(
        'jjlazo_project_metabox',
        __('Project Information', 'jjlazo'),
        'jjlazo_project_metabox_html',
        'porfolio',
        'normal',
        'default'
    );
}
add_action('add_meta_boxes', 'jjlazo_add_meta_box');

/**
 * Post metabox
 *
 * @param obj $post
 * @return void
 */
function jjlazo_post_metabox_html($post)
{
    $subtitle = get_post_meta($post->ID, '_jjlazo_post_subtitle', true);
    $layout   = get_post_meta($post->ID, '_jjlazo_post_layout', true);
    wp_nonce_field('jjlazo_update_post_metabox', 'jjlazo_update_post_nonce');
?>
    <p>
        <label for="jjlazo_post_metabox_html"><?php esc_html_e('Post Subtitle', 'jjlazo'); ?></label>
        <br />
        <input class="widefat" type="text" name="jjlazo_post_subtitle_field" id="jjlazo_post_metabox_html" value="<?php echo esc_attr($subtitle); ?>" />
    </p>
    <p>
        <label for="jjlazo_post_layout_field"><?php esc_html_e('Layout', 'jjlazo'); ?></label>
        <select name="jjlazo_post_layout_field" id="jjlazo_post_layout_field" class="widefat">
            <option <?php selected($layout, 'full'); ?> value="full"><?php esc_html_e('Full Width', 'jjlazo'); ?></option>
            <option <?php selected($layout, 'sidebar'); ?> value="sidebar"><?php esc_html_e('Post With Sidebar', 'jjlazo'); ?></option>
        </select>
    </p>
<?php
}

/**
 * project metabox
 *
 * @param obj $post
 * @return void
 */
function jjlazo_project_metabox_html($post)
{
    $project_client  = get_post_meta($post->ID, '_jjlazo_porfolio_details_project_client', true);
    $project_url     = get_post_meta($post->ID, '_jjlazo_porfolio_details_project_url', true);
    $project_gallery = get_post_meta($post->ID, '_jjlazo_porfolio_details_project_gallery');
    wp_nonce_field('jjlazo_update_post_metabox', 'jjlazo_update_post_nonce');
?>
    <p>
        <label for="jjlazo_project_client_field"><?php esc_html_e('Project client', 'jjlazo'); ?></label>
        <br />
        <input class="widefat" type="text" name="jjlazo_project_client_field" id="jjlazo_project_client_field" value="<?php echo esc_attr($project_client); ?>" />
    </p>
    <p>
        <label for="jjlazo_project_url_field"><?php esc_html_e('Project URL', 'jjlazo'); ?></label>
        <br />
        <input class="widefat" type="url" name="jjlazo_project_url_field" id="jjlazo_project_url_field" value="<?php echo esc_attr($project_url); ?>" />
    </p>
    <p>
        <label for="_jjlazo_porfolio_details_project_gallery"><?php esc_html_e('Project gallery', 'jjlazo'); ?></label>
        <br />
        <input type="file" id="_jjlazo_porfolio_details_project_gallery" name="_jjlazo_porfolio_details_project_gallery" />
        <div class="u-flex">
            <?php foreach ($project_gallery as $project_image) { ?>
                <div class="show-file">
                    <span class="delete"></span>
                    <img style="max-width:150px;max-height:150px;" src="<?php echo $project_image['url']; ?>" class="img-fluid" alt="">
                </div>
            <?php } ?>
        </div>
    </p>
<?php
}

function jjlazo_save_post_metabox($post_id, $post)
{

    $edit_cap = get_post_type_object($post->post_type)->cap->edit_post;
    if (!current_user_can($edit_cap, $post_id)) {
        return;
    } // end if

    if (!isset($_POST['jjlazo_update_post_nonce']) || !wp_verify_nonce($_POST['jjlazo_update_post_nonce'], 'jjlazo_update_post_metabox')) {
        return;
    } // end if

    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return $post_id;
    } // end if

    if (array_key_exists('jjlazo_post_subtitle_field', $_POST)) {
        update_post_meta(
            $post_id,
            '_jjlazo_post_subtitle',
            sanitize_text_field($_POST['jjlazo_post_subtitle_field'])
        );
    } // end if

    if (array_key_exists('jjlazo_post_layout_field', $_POST)) {
        update_post_meta(
            $post_id,
            '_jjlazo_post_layout',
            sanitize_text_field($_POST['jjlazo_post_layout_field'])
        );
    } // end if

    if (array_key_exists('jjlazo_project_client_field', $_POST)) {
        update_post_meta(
            $post_id,
            '_jjlazo_porfolio_details_project_client',
            sanitize_text_field($_POST['jjlazo_project_client_field'])
        );
    } // end if

    if (array_key_exists('jjlazo_project_url_field', $_POST)) {
        update_post_meta(
            $post_id,
            '_jjlazo_porfolio_details_project_url',
            sanitize_text_field($_POST['jjlazo_project_url_field'])
        );
    } // end if

    // Make sure the file array isn't empty
    if (!empty($_FILES['_jjlazo_porfolio_details_project_gallery']['name'])) {

        // Setup the array of supported file types. In this case, it's just PDF.
        $supported_types = array('application/pdf', 'image/jpeg', 'image/png', 'image/jpeg');

        // Get the file type of the upload
        $arr_file_type = wp_check_filetype(basename($_FILES['_jjlazo_porfolio_details_project_gallery']['name']));
        $uploaded_type = $arr_file_type['type'];

        // Check if the type is supported. If not, throw an error.
        if (in_array($uploaded_type, $supported_types)) {

            // Use the WordPress API to upload the file
            $upload = wp_upload_bits($_FILES['_jjlazo_porfolio_details_project_gallery']['name'], null, file_get_contents($_FILES['_jjlazo_porfolio_details_project_gallery']['tmp_name']));

            if (isset($upload['error']) && $upload['error'] != 0) {
                wp_die('There was an error uploading your file. The error is: ' . $upload['error']);
            } else {
                add_post_meta($post_id, '_jjlazo_porfolio_details_project_gallery', $upload);
                update_post_meta($post_id, '_jjlazo_porfolio_details_project_gallery', $upload);
            } // end if/else

        } else {
            wp_die("The file type that you've uploaded is not a PDF.");
        } // end if/else

    } // end if
}

add_action('save_post', 'jjlazo_save_post_metabox', 10, 2);
