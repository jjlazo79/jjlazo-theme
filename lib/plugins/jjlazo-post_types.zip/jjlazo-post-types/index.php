<?php
/*
Plugin Name:  jjlazo post_types
Plugin URI:
Description:  Adding Custom Post Types for jjlazo
Version:      1.0.0
Author:       Jose Lazo
Author URI:   https://joselazo.es/
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  jjlazo-post_types
Domain Path:  /languages
*/

if (!defined('WPINC')) {
	die;
}

include_once('includes/porfolio-post-type.php');
include_once('includes/project-type-tax.php');
include_once('includes/skills-tax.php');
