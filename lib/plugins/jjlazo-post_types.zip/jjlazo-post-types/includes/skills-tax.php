<?php
add_action('init', 'porfolio_tax_register');

function portfolio_tax_register()
{
	// registering SKILL taxonomy

	$labels = array(
		'name' 							=> __('Skills', 'jjlazo'),
		'singular_name' 				=> __('Skill', 'jjlazo'),
		'search_items' 					=>  __('Search Skills', 'jjlazo'),
		'popular_items' 				=> __('Popular Skills', 'jjlazo'),
		'all_items' 					=> __('All Skills', 'jjlazo'),
		'parent_item' 					=> null,
		'parent_item_colon' 			=> null,
		'edit_item' 					=> __('Edit Skill', 'jjlazo'),
		'update_item' 					=> __('Update Skill', 'jjlazo'),
		'add_new_item' 					=> __('Add New Skill', 'jjlazo'),
		'new_item_name' 				=> __('New Skill Name', 'jjlazo'),
		'separate_items_with_commas' 	=> __('Separate skills with commas', 'jjlazo'),
		'add_or_remove_items' 			=> __('Add or remove skills', 'jjlazo'),
		'choose_from_most_used' 		=> __('Choose from the most used skills', 'jjlazo'),
		'menu_name' 					=> __('Skills', 'jjlazo')
	);

	$args = array(
		'labels' 				=> $labels,
		'hierarchical' 			=> false,
		'show_ui' 				=> true,
		'show_in_nav_menus'		=> false,
		'update_count_callback' => '_update_post_term_count',
		'query_var' 			=> true,
		'rewrite' 				=> true
	);

	register_taxonomy('porfolio_skill', array('porfolio'), $args);
}
