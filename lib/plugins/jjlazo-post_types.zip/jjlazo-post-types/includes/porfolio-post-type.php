<?php
add_action('init', 'porfolio_register');

function porfolio_register()
{
	// registering PORFOLIO post type

	$labels = array(
		'name'					=> __('Porfolio', 'jjlazo'),
		'singular_name'			=> __('Project', 'jjlazo'),
		'add_new' 				=> __('Add New', 'jjlazo'),
		'add_new_item' 			=> __('Add New Project', 'jjlazo'),
		'edit_item' 			=> __('Edit Project', 'jjlazo'),
		'new_item' 				=> __('New Project', 'jjlazo'),
		'all_items' 			=> __('All Projects', 'jjlazo'),
		'view_item' 			=> __('View Project', 'jjlazo'),
		'search_items' 			=> __('Search Projects', 'jjlazo'),
		'not_found' 			=> __('No projects found', 'jjlazo'),
		'not_found_in_trash' 	=> __('No projects found in Trash', 'jjlazo'),
		'parent_item_colon' 	=> '',
		'menu_name' 			=> __('Porfolio', 'jjlazo'),
	);

	$args = array(
		'labels'				=> $labels,
		'public'				=> true,
		'show_ui'				=> true,
		'show_in_menu' 			=> true,
		'show_in_nav_menus'		=> true,
		'show_in_rest'			=> true,
		'menu_position' 		=> 5,
		'menu_icon'				=> 'dashicons-porfolio',
		'query_var' 			=> true,
		'capability_type' 		=> 'post',
		'hierarchical' 			=> false,
		'has_archive'			=> true,
		'supports' 				=> array('title', 'thumbnail', 'excerpt', 'editor', 'page-attributes'),
		'rewrite'				=> array(
			'slug'			=> 'porfolio',
			'with_front'	=> true
		)
	);

	register_post_type('porfolio', $args);
}
