<?php
add_action('init', 'porfolio_category_register');

function portfolio_category_register()
{
	// registering CATEGORY taxonomy

	$labels = array(
		'name' 				=> __('Categories', 'jjlazo'),
		'singular_name' 	=> __('Category', 'jjlazo'),
		'search_items' 		=> __('Search Categories', 'jjlazo'),
		'all_items' 		=> __('All Categories', 'jjlazo'),
		'parent_item' 		=> __('Parent Category', 'jjlazo'),
		'parent_item_colon'	=> __('Parent Category:', 'jjlazo'),
		'edit_item' 		=> __('Edit Category', 'jjlazo'),
		'update_item' 		=> __('Update Category', 'jjlazo'),
		'add_new_item' 		=> __('Add New Category', 'jjlazo'),
		'new_item_name' 	=> __('New Category Name', 'jjlazo'),
		'menu_name' 		=> __('Categories', 'jjlazo')
	);

	$args = array(
		'labels' 			=> $labels,
		'hierarchical' 		=> true,
		'show_ui' 			=> true,
		'show_in_nav_menus' => false,
		'query_var' 		=> true,
		'rewrite' 			=> true
	);

	register_taxonomy('porfolio_category', array('porfolio'), $args);
}
